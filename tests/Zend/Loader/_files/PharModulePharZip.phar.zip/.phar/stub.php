<?php // zip-based phar archive stub file
__HALT_COMPILER();