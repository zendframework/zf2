<?php

namespace PharModulePharTar;

class Module
{} 