<?php

namespace PharModuleTar;

class Module
{} 